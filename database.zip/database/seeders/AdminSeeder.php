<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admins = [];
        for ($i = 1; $i <= 7; $i++) {
            $username = 'admin' . $i;
            $row = [];
            if (Schema::hasColumn('users', 'name')) {
                $row['name'] = 'Admin ' . $i;
            }
            if (Schema::hasColumn('users', 'nama')) {
                $row['nama'] = 'Admin ' . $i;
            }
            if (Schema::hasColumn('users', 'email')) {
                $row['email'] = $username . '@example.com';
            }
            if (Schema::hasColumn('users', 'username')) {
                $row['username'] = $username;
            }
            if (Schema::hasColumn('users', 'password')) {
                $row['password'] = Hash::make('admin123');
            }
            if (Schema::hasColumn('users', 'role')) {
                $row['role'] = 'admin';
            }
            if (Schema::hasColumn('users', 'kelas')) {
                $row['kelas'] = null;
            }
            if (Schema::hasColumn('users', 'created_at')) {
                $row['created_at'] = now();
            }
            if (Schema::hasColumn('users', 'updated_at')) {
                $row['updated_at'] = now();
            }

            // avoid duplicates
            if (!empty($row) && !DB::table('users')->where('username', $username)->exists()) {
                $admins[] = $row;
            }
        }

        DB::table('users')->insert($admins);
    }
}
