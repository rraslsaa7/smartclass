<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class StudentsSeeder extends Seeder
{
    public function run(): void
    {
        $siswa = [
            ['nama' => 'Achmad Rifki', 'username' => 'rifki'],
            ['nama' => 'Agung Satria', 'username' => 'agung'],
            ['nama' => 'Agus Hardiansah', 'username' => 'agus'],
            ['nama' => 'Aira Salsa', 'username' => 'aira'],
            ['nama' => 'Alfarrel Adha', 'username' => 'alfarrel'],
            ['nama' => 'Ariyo Wareh', 'username' => 'ariyo'],
            ['nama' => 'Belva Devara', 'username' => 'belva'],
            ['nama' => 'Dhinda Rachmawati', 'username' => 'dhinda'],
            ['nama' => 'Dimas Aji', 'username' => 'dimas'],
            ['nama' => 'Djakfar Fawwas', 'username' => 'djakfar'],
            ['nama' => 'Fahri Ainur', 'username' => 'fahri'],
            ['nama' => 'Ilfanti Verdiana', 'username' => 'ilfanti'],
            ['nama' => 'Kirana Aliyah', 'username' => 'kirana'],
            ['nama' => 'Kofifa Wahyu', 'username' => 'kofifa'],
            ['nama' => 'Maulana Yaskaafi', 'username' => 'maulana'],
            ['nama' => 'M. Akbar', 'username' => 'akbar'],
            ['nama' => 'M. Alief', 'username' => 'alief'],
            ['nama' => 'M. Fauzan', 'username' => 'fauzan'],
            ['nama' => 'M. Alfaqih', 'username' => 'alfaqih'],
            ['nama' => 'M. Kevin', 'username' => 'kevin'],
            ['nama' => 'Nafis Choirul', 'username' => 'nafis'],
            ['nama' => 'Ordi Kurniawan', 'username' => 'ordi'],
            ['nama' => 'Pinkkan Septy', 'username' => 'pinkkan'],
            ['nama' => 'Radimas Fahardika', 'username' => 'radimas'],
            ['nama' => 'Raditya Rizki', 'username' => 'raditya'],
            ['nama' => 'Ria Oktavia', 'username' => 'ria'],
            ['nama' => 'Shiva Purna', 'username' => 'shiva'],
            ['nama' => 'Yasmin Aulia', 'username' => 'yasmin'],
        ];

        $now = now();
        $rows = [];
        foreach ($siswa as $s) {
            $row = [];
            if (Schema::hasColumn('users', 'name')) {
                $row['name'] = $s['nama'];
            }
            if (Schema::hasColumn('users', 'nama')) {
                $row['nama'] = $s['nama'];
            }
            if (Schema::hasColumn('users', 'email')) {
                $row['email'] = $s['username'].'@example.local';
            }
            if (Schema::hasColumn('users', 'username')) {
                $row['username'] = $s['username'];
            }
            if (Schema::hasColumn('users', 'password')) {
                $row['password'] = Hash::make('siswa123');
            }
            if (Schema::hasColumn('users', 'role')) {
                $row['role'] = 'siswa';
            }
            if (Schema::hasColumn('users', 'kelas')) {
                $row['kelas'] = 'XI RPL 2';
            }
            if (Schema::hasColumn('users', 'created_at')) {
                $row['created_at'] = $now;
            }
            if (Schema::hasColumn('users', 'updated_at')) {
                $row['updated_at'] = $now;
            }

            // insert new or update existing user's password and basic info
            if (!empty($row)) {
                if (isset($row['username']) && DB::table('users')->where('username', $row['username'])->exists()) {
                    $update = [];
                    if (isset($row['password'])) $update['password'] = $row['password'];
                    if (isset($row['name'])) $update['name'] = $row['name'];
                    if (isset($row['nama'])) $update['nama'] = $row['nama'];
                    if (isset($row['kelas'])) $update['kelas'] = $row['kelas'];
                    if (!empty($update)) {
                        DB::table('users')->where('username', $row['username'])->update($update);
                    }
                } else {
                    $rows[] = $row;
                }
            }
        }

        DB::table('users')->insert($rows);
    }
}
