<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('tugas_submissions')) {
            Schema::create('tugas_submissions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('tugas_id')->index();
                $table->unsignedBigInteger('user_id')->index();
                $table->string('file_path');
                $table->timestamp('submitted_at')->nullable();
                $table->timestamps();

                // avoid strict foreign key creation to prevent cross-engine/charset issues
                // Developers can add FK constraints manually if the DB is prepared
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tugas_submissions');
    }
};
