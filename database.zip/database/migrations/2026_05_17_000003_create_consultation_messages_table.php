<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('consultation_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('consultation_id');
            $table->unsignedBigInteger('user_id');
            $table->text('message')->nullable();
            $table->string('attachment_path')->nullable();
            $table->timestamps();

            // foreign keys intentionally omitted to avoid constraint errors on some MySQL setups
        });
    }

    public function down()
    {
        Schema::dropIfExists('consultation_messages');
    }
};
