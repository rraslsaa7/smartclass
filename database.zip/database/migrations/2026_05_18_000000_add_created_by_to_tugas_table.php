<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('tugas') && ! Schema::hasColumn('tugas', 'created_by')) {
            Schema::table('tugas', function (Blueprint $table) {
                $table->unsignedBigInteger('created_by')->nullable()->after('status');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('tugas') && Schema::hasColumn('tugas', 'created_by')) {
            Schema::table('tugas', function (Blueprint $table) {
                $table->dropColumn('created_by');
            });
        }
    }
};
