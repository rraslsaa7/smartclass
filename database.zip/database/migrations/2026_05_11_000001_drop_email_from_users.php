<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('users', 'email')) {
            Schema::table('users', function (Blueprint $table) {
                // drop unique index if present
                if (Schema::hasColumn('users', 'email')) {
                    // attempt to drop index; ignore if not exists
                    try {
                        $table->dropUnique(['email']);
                    } catch (\Throwable $e) {
                        // ignore
                    }
                }
                $table->dropColumn('email');
            });
        }
    }

    public function down(): void
    {
        if (!Schema::hasColumn('users', 'email')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('email')->unique()->nullable()->after('name');
            });
        }
    }
};
