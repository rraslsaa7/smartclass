<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tugas', function (Blueprint $table) {
            if (!Schema::hasColumn('tugas', 'file_path')) {
                $table->string('file_path')->nullable()->after('kelas');
            }
            if (!Schema::hasColumn('tugas', 'file')) {
                $table->string('file')->nullable()->after('file_path');
            }
            if (!Schema::hasColumn('tugas', 'title')) {
                $table->string('title')->nullable()->after('file');
            }
            if (!Schema::hasColumn('tugas', 'description')) {
                $table->text('description')->nullable()->after('title');
            }
            if (!Schema::hasColumn('tugas', 'judul')) {
                $table->string('judul')->nullable()->after('description');
            }
            if (!Schema::hasColumn('tugas', 'deskripsi')) {
                $table->text('deskripsi')->nullable()->after('judul');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tugas', function (Blueprint $table) {
            if (Schema::hasColumn('tugas', 'deskripsi')) {
                $table->dropColumn('deskripsi');
            }
            if (Schema::hasColumn('tugas', 'judul')) {
                $table->dropColumn('judul');
            }
            if (Schema::hasColumn('tugas', 'description')) {
                $table->dropColumn('description');
            }
            if (Schema::hasColumn('tugas', 'title')) {
                $table->dropColumn('title');
            }
            if (Schema::hasColumn('tugas', 'file')) {
                $table->dropColumn('file');
            }
            if (Schema::hasColumn('tugas', 'file_path')) {
                $table->dropColumn('file_path');
            }
        });
    }
};
