<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('consultations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tugas_id')->nullable();
            $table->unsignedBigInteger('student_id');
            $table->unsignedBigInteger('teacher_id')->nullable();
            $table->string('subject')->nullable();
            $table->enum('status', ['open','closed'])->default('open');
            $table->timestamps();

            // foreign keys intentionally omitted to avoid engine/constraint issues
            // consider adding constraints later if your MySQL supports InnoDB and matching collation
        });
    }

    public function down()
    {
        Schema::dropIfExists('consultations');
    }
};
