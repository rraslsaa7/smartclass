<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('tugas') && Schema::hasColumn('tugas', 'judul')) {
            DB::statement("ALTER TABLE `tugas` MODIFY `judul` VARCHAR(255) NULL");
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('tugas') && Schema::hasColumn('tugas', 'judul')) {
            DB::statement("ALTER TABLE `tugas` MODIFY `judul` VARCHAR(255) NOT NULL");
        }
    }
};
