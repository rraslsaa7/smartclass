<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tugas_submissions', function (Blueprint $table) {
            if (!Schema::hasColumn('tugas_submissions', 'grade')) {
                $table->decimal('grade',5,2)->nullable()->after('file_path');
            }
            if (!Schema::hasColumn('tugas_submissions', 'feedback')) {
                $table->text('feedback')->nullable()->after('grade');
            }
            if (!Schema::hasColumn('tugas_submissions', 'graded_by')) {
                $table->unsignedBigInteger('graded_by')->nullable()->after('feedback');
            }
            if (!Schema::hasColumn('tugas_submissions', 'graded_at')) {
                $table->timestamp('graded_at')->nullable()->after('graded_by');
            }
            if (!Schema::hasColumn('tugas_submissions', 'needs_remedial')) {
                $table->boolean('needs_remedial')->default(false)->after('graded_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tugas_submissions', function (Blueprint $table) {
            if (Schema::hasColumn('tugas_submissions', 'needs_remedial')) $table->dropColumn('needs_remedial');
            if (Schema::hasColumn('tugas_submissions', 'graded_at')) $table->dropColumn('graded_at');
            if (Schema::hasColumn('tugas_submissions', 'graded_by')) $table->dropColumn('graded_by');
            if (Schema::hasColumn('tugas_submissions', 'feedback')) $table->dropColumn('feedback');
            if (Schema::hasColumn('tugas_submissions', 'grade')) $table->dropColumn('grade');
        });
    }
};
