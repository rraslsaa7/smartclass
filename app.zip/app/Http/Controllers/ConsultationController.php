<?php

namespace App\Http\Controllers;

use App\Models\Consultation;
use App\Models\ConsultationMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ConsultationController extends Controller
{
    public function index()
    {
        $user = session('user');
        if (!$user) return redirect()->route('login');

        if (($user->role ?? '') === 'admin') {
            $items = Consultation::latest()->with('student')->get();
        } else {
            $items = Consultation::where('student_id', $user->id)->latest()->get();
        }

        return view('consultations.index', compact('items'));
    }

    public function create(Request $request)
    {
        $tugasId = $request->get('tugas_id');
        return view('consultations.create', compact('tugasId'));
    }

    public function store(Request $request)
    {
        $user = session('user');
        if (!$user) return redirect()->route('login');

        $data = $request->validate([
            'tugas_id' => 'nullable|exists:tugas,id',
            'subject' => 'required|string|max:255',
            'message' => 'nullable|string',
            'attachment' => 'nullable|file|mimes:pdf,doc,docx,png,jpg,jpeg,zip|max:10240',
        ]);

        $consult = Consultation::create([
            'tugas_id' => $data['tugas_id'] ?? null,
            'student_id' => $user->id,
            'subject' => $data['subject'],
            'status' => 'open',
        ]);

        if (($data['message'] ?? null) || $request->hasFile('attachment')) {
            $path = null;
            if ($request->hasFile('attachment')) {
                $path = $request->file('attachment')->store('public/consultations');
            }

            ConsultationMessage::create([
                'consultation_id' => $consult->id,
                'user_id' => $user->id,
                'message' => $data['message'] ?? null,
                'attachment_path' => $path,
            ]);
        }

        return redirect()->route('consultations.show', $consult->id)->with('success','Konsultasi dibuat');
    }

    public function show(Consultation $consultation)
    {
        $user = session('user');
        if (!$user) return redirect()->route('login');

        // access control: student owner or admin
        if (($user->role ?? '') !== 'admin' && $consultation->student_id !== $user->id) {
            return redirect()->route('consultations.index')->with('error','Akses ditolak');
        }

        $messages = $consultation->messages()->with('user')->latest()->get();
        return view('consultations.show', compact('consultation','messages'));
    }

    public function message(Request $request, Consultation $consultation)
    {
        $user = session('user');
        if (!$user) return redirect()->route('login');

        // access control
        if (($user->role ?? '') !== 'admin' && $consultation->student_id !== $user->id) {
            return redirect()->route('consultations.index')->with('error','Akses ditolak');
        }

        $data = $request->validate([
            'message' => 'nullable|string',
            'attachment' => 'nullable|file|mimes:pdf,doc,docx,png,jpg,jpeg,zip|max:10240',
            'action' => 'nullable|string',
        ]);

        $path = null;
        if ($request->hasFile('attachment')) {
            $path = $request->file('attachment')->store('public/consultations');
        }

        ConsultationMessage::create([
            'consultation_id' => $consultation->id,
            'user_id' => $user->id,
            'message' => $data['message'] ?? null,
            'attachment_path' => $path,
        ]);

        if (($data['action'] ?? '') === 'close' && ($user->role ?? '') === 'admin') {
            $consultation->update(['status' => 'closed', 'teacher_id' => $user->id]);
        }

        return redirect()->route('consultations.show', $consultation->id)->with('success','Pesan terkirim');
    }
}
