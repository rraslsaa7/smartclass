<?php

namespace App\Http\Controllers;

use App\Models\Tugas;
use App\Models\Material;
use App\Models\TugasSubmission;
use App\Models\Consultation;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $user = session('user');

        $tugasCount = Tugas::where('status', 'open')->count();
        $materialsCount = Material::count();
        $avgScore = round(TugasSubmission::whereNotNull('grade')->avg('grade') ?? 0, 2);
        $consultationsCount = Consultation::where('status', 'open')->count();

        // latest tasks
        $latestTugas = Tugas::where('status', 'open')->latest()->take(5)->get();

        // latest consultations: admin sees all, student sees own
        if (! $user) {
            $latestConsultations = collect();
        } elseif (($user->role ?? '') === 'admin') {
            $latestConsultations = Consultation::with('student')->latest()->take(5)->get();
        } else {
            $latestConsultations = Consultation::with('student')->where('student_id', $user->id)->latest()->take(5)->get();
        }

        return view('dashboard', compact(
            'tugasCount', 'materialsCount', 'avgScore', 'consultationsCount', 'latestTugas', 'latestConsultations'
        ));
    }
}