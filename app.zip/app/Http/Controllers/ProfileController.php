<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Consultation;
use App\Models\ConsultationMessage;
use App\Models\User;

class ProfileController extends Controller
{
    public function index()
    {
        return view('profil.index');
    }

    public function update(Request $request)
    {
        $user = session('user');
        if (! $user) return redirect()->route('login');

        $data = $request->validate([
            'nama' => 'required|string|max:255',
            'phone' => 'nullable|string|max:50',
            'address' => 'nullable|string',
            'avatar' => 'nullable|image|max:2048',
        ]);

        // handle avatar upload
        if ($request->hasFile('avatar')) {
            $path = $request->file('avatar')->store('public/avatars');
            $data['avatar'] = $path;
        }

        $userModel = User::find($user->id);
        // map nama -> nama column
        if (isset($data['nama'])) $userModel->nama = $data['nama'];
        $userModel->phone = $data['phone'] ?? $userModel->phone;
        $userModel->address = $data['address'] ?? $userModel->address;
        if (isset($data['avatar'])) $userModel->avatar = $data['avatar'];
        $userModel->save();

        // refresh session user
        session(['user' => $userModel]);

        return redirect()->route('profil.index')->with('success','Profil berhasil disimpan');
    }

    public function clearConsultations(Request $request)
    {
        $user = session('user');
        if (! $user) return redirect()->route('login');

        // delete consultations where user is student or teacher
        $items = Consultation::where('student_id', $user->id)->orWhere('teacher_id', $user->id)->get();
        foreach ($items as $c) {
            $c->messages()->delete();
            $c->delete();
        }

        return redirect()->route('profil.index')->with('success','Riwayat konsultasi dihapus');
    }
}
