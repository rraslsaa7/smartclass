<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

class AuthController extends Controller
{
    public function login(){
        return view('auth.login');
    }

    public function register(){
        return view('auth.register');
    }

    public function registerPost(Request $request){
        $validated = $request->validate([
            'nama' => 'required|string|max:100',
            'username' => 'required|string|max:50|unique:users,username',
            'password' => 'required|string|min:6|confirmed',
            'kelas' => 'nullable|string|max:50',
        ]);

        $data = [];
        if (Schema::hasColumn('users', 'name')) {
            $data['name'] = $validated['nama'];
        }
        if (Schema::hasColumn('users', 'nama')) {
            $data['nama'] = $validated['nama'];
        }
        if (Schema::hasColumn('users', 'email')) {
            $data['email'] = $request->input('email') ?? $validated['username'].'@example.local';
        }

        $data['username'] = $validated['username'];
        $data['password'] = Hash::make($validated['password']);
        if (Schema::hasColumn('users', 'role')) {
            $data['role'] = 'siswa';
        }
        if (Schema::hasColumn('users', 'kelas')) {
            $data['kelas'] = $validated['kelas'] ?? null;
        }
        if (Schema::hasColumn('users', 'created_at')) {
            $data['created_at'] = now();
        }

        // remove null values so insert doesn't fail for missing optional columns
        $insert = array_filter($data, function($v){ return $v !== null; });

        DB::table('users')->insert($insert);

        return redirect()->route('login');
    }

    public function loginPost(Request $request){
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = DB::table('users')->where('username', $request->username)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            session(['user' => $user]);
            return redirect('/dashboard');
        }

        return back()->with('error', 'Login gagal');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('user');
        $request->session()->flush();
        return redirect()->route('login');
    }
}