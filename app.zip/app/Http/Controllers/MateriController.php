<?php

namespace App\Http\Controllers;

use App\Models\Material;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class MateriController extends Controller
{
    public function index(Request $request)
    {
        $query = Material::query();

        if ($request->filled('mapel')) $query->where('mapel', $request->mapel);
        if ($request->filled('kelas')) $query->where('kelas', $request->kelas);

        $materials = $query->latest()->get();
        return view('materi.index', compact('materials'));
    }

    public function create()
    {
        $user = session('user');
        if (! $user || ($user->role ?? '') !== 'admin') {
            return redirect()->route('materi.index')->with('error','Akses ditolak');
        }
        return view('materi.create');
    }

    public function store(Request $request)
    {
        $user = session('user');
        if (! $user || ($user->role ?? '') !== 'admin') {
            return redirect()->route('materi.index')->with('error','Akses ditolak');
        }

        $data = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'mapel' => 'nullable|string|max:100',
            'kelas' => 'nullable|string|max:50',
            'file' => 'nullable|file|mimes:pdf,doc,docx,ppt,pptx,zip|max:20480',
        ]);

        if ($request->hasFile('file')) {
            $data['file_path'] = $request->file('file')->store('public/materi');
        }

        $data['created_by'] = $user->id;

        Material::create($data);

        return redirect()->route('materi.index')->with('success','Materi ditambahkan');
    }

    public function show(Material $materi)
    {
        return view('materi.show', ['materi' => $materi]);
    }

    public function download(Material $materi)
    {
        if (! $materi->file_path || ! Storage::exists($materi->file_path)) {
            return back()->with('error','File tidak ditemukan');
        }

        return Storage::download($materi->file_path);
    }

    public function destroy(Material $materi)
    {
        $user = session('user');
        if (! $user || ($user->role ?? '') !== 'admin') {
            return redirect()->route('materi.index')->with('error','Akses ditolak');
        }

        if ($materi->file_path) Storage::delete($materi->file_path);
        $materi->delete();

        return redirect()->route('materi.index')->with('success','Materi dihapus');
    }
}
