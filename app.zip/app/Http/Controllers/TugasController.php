<?php

namespace App\Http\Controllers;

use App\Models\Tugas;
use App\Models\TugasSubmission;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TugasController extends Controller
{
    public function index()
    {
        $tugas = Tugas::latest()->get();
        return view('tugas.index', compact('tugas'));
    }

    public function create()
    {
        if (!$this->isAdmin()) {
            return redirect()->route('tugas.index')->with('error','Akses ditolak');
        }
        return view('tugas.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'mapel' => 'nullable|string|max:100',
            'kelas' => 'nullable|string|max:50',
            'deadline' => 'nullable|date',
            'file' => 'nullable|file|mimes:pdf,doc,docx,ppt,pptx|max:10240',
        ]);

        // upload file
        if ($request->hasFile('file')) {
            $data['file_path'] = $request->file('file')->store('public/tugas');
        }

        $data['status'] = 'open';
        $data['created_by'] = session('user')->id ?? null;

        // ensure compatibility with database columns using Indonesian names
        if (isset($data['title'])) {
            $data['judul'] = $data['title'];
        }
        if (isset($data['description'])) {
            $data['deskripsi'] = $data['description'];
        }

        Tugas::create($data);

        return redirect()->route('tugas.index')->with('success','Data berhasil ditambahkan');
    }

    public function show(Tugas $tugas)
    {
        $user = session('user');
        $submissions = collect();
        $mySubmission = null;

        if ($this->isAdmin()) {
            $submissions = TugasSubmission::where('tugas_id', $tugas->id)->with('grader')->get();
        } elseif ($user) {
            $mySubmission = TugasSubmission::where('tugas_id', $tugas->id)->where('user_id', $user->id)->with('grader')->first();
        }

        return view('tugas.show', compact('tugas','submissions','mySubmission'));
    }

    public function grade(Request $request, TugasSubmission $submission)
    {
        if (!$this->isAdmin()) {
            return redirect()->back()->with('error','Akses ditolak');
        }

        $data = $request->validate([
            'grade' => 'nullable|numeric|min:0|max:100',
            'feedback' => 'nullable|string',
            'needs_remedial' => 'nullable|in:on,1',
        ]);

        $submission->grade = $data['grade'] ?? null;
        $submission->feedback = $data['feedback'] ?? null;
        $submission->graded_by = session('user')->id ?? null;
        $submission->graded_at = now();
        $submission->needs_remedial = isset($data['needs_remedial']) ? true : false;
        $submission->save();

        return redirect()->back()->with('success','Nilai tersimpan');
    }

    public function edit(Tugas $tugas)
    {
        if (!$this->isAdmin()) {
            return redirect()->route('tugas.index')->with('error','Akses ditolak');
        }
        return view('tugas.edit', compact('tugas'));
    }

    public function update(Request $request, Tugas $tugas)
    {
        if (!$this->isAdmin()) {
            return redirect()->route('tugas.index')->with('error','Akses ditolak');
        }

        $data = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'mapel' => 'nullable|string|max:100',
            'kelas' => 'nullable|string|max:50',
            'deadline' => 'nullable|date',
            'file' => 'nullable|file|mimes:pdf,doc,docx,ppt,pptx|max:10240',
        ]);

        // upload file baru
        if ($request->hasFile('file')) {
            if ($tugas->file_path) {
                Storage::delete($tugas->file_path);
            }

            $data['file_path'] = $request->file('file')->store('public/tugas');
            $data['file'] = basename($data['file_path']);
        }

        // keep Indonesian column in sync
        if (isset($data['title'])) {
            $data['judul'] = $data['title'];
        }
        if (isset($data['description'])) {
            $data['deskripsi'] = $data['description'];
        }

        $tugas->update($data);

        return redirect()->route('tugas.index')->with('success','Data berhasil diupdate');
    }

    public function destroy(Tugas $tugas)
    {
        if (!$this->isAdmin()) {
            return redirect()->route('tugas.index')->with('error','Akses ditolak');
        }

        if ($tugas->file_path) {
            Storage::delete($tugas->file_path);
        }

        $tugas->delete();

        return redirect()->route('tugas.index')->with('success','Data berhasil dihapus');
    }

    public function download(Tugas $tugas)
    {
        if (!$tugas->file_path || !Storage::exists($tugas->file_path)) {
            return back()->with('error','File tidak ditemukan');
        }

        return Storage::download($tugas->file_path);
    }

    public function submit(Request $request, Tugas $tugas)
    {
        // only siswa can submit
        $user = session('user');
        if (!$user || ($user->role ?? 'siswa') === 'admin') {
            return redirect()->route('tugas.show', $tugas->id)->with('error','Akses ditolak');
        }

        $data = $request->validate([
            'file' => 'required|file|mimes:pdf,doc,docx,zip|max:10240',
        ]);

        $path = $request->file('file')->store('public/tugas_submissions');

        $submission = TugasSubmission::create([
            'tugas_id' => $tugas->id,
            'user_id' => $user->id,
            'file_path' => $path,
            'submitted_at' => now(),
        ]);

        return redirect()->route('tugas.show', $tugas->id)->with('success','Tugas berhasil dikumpulkan');
    }

    private function isAdmin(): bool
    {
        $user = session('user');
        if (!$user) return false;

        // treat role=='admin' or username in specific teacher admins as admin (guru)
        $teacherUsernames = array_map(function($i){return 'admin'.$i;}, range(1,7));

        if (isset($user->role) && $user->role === 'admin') return true;
        if (isset($user->username) && in_array($user->username, $teacherUsernames, true)) return true;

        return false;
    }
}