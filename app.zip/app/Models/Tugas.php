<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tugas extends Model
{
    use HasFactory;

    protected $table = 'tugas';

    protected $fillable = [
        'title',
        'description',
        'mapel',
        'kelas',
        'file_path',
        'file',
        'judul',
        'deskripsi',
        'deadline',
        'status',
        'created_by',
    ];
}