<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TugasSubmission extends Model
{
    use HasFactory;

    protected $table = 'tugas_submissions';

    protected $fillable = [
        'tugas_id',
        'user_id',
        'file_path',
        'submitted_at',
        'grade',
        'feedback',
        'graded_by',
        'graded_at',
        'needs_remedial',
    ];

    public function grader()
    {
        return $this->belongsTo(User::class, 'graded_by');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
