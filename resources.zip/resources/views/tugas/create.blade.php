@extends('layouts.app')
@section('title','Buat Tugas')
@section('content')
<div class="card">
  <h3>Buat Tugas Baru</h3>
  @if(session('error'))<div style="color:#b00020">{{ session('error') }}</div>@endif
  <form method="POST" action="{{ route('tugas.store') }}" enctype="multipart/form-data" style="margin-top:12px">
    @csrf
    <div style="display:grid;gap:8px">
      <input type="text" name="title" placeholder="Judul tugas" required style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="mapel" placeholder="Mapel" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="kelas" placeholder="Kelas" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="datetime-local" name="deadline" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <textarea name="description" placeholder="Deskripsi" rows="4" style="padding:10px;border-radius:8px;border:1px solid #e6eefc"></textarea>
      <input type="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx">
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" type="submit">Simpan</button>
        <a href="{{ route('tugas.index') }}" class="btn" style="background:#eef6ff;border-radius:8px">Batal</a>
      </div>
    </div>
  </form>
</div>
@endsection

