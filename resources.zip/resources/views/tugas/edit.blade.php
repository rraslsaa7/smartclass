@extends('layouts.app')
@section('title','Edit Tugas')
@section('content')
<div class="card">
  <h3>Edit Tugas</h3>
  <form action="{{ route('tugas.update', $tugas->id) }}" method="POST" enctype="multipart/form-data" style="margin-top:12px">
    @csrf @method('PUT')
    <div style="display:grid;gap:8px">
      <input type="text" name="title" value="{{ $tugas->title }}" required style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="mapel" value="{{ $tugas->mapel }}" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="kelas" value="{{ $tugas->kelas }}" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="datetime-local" name="deadline" value="{{ $tugas->deadline ? date('Y-m-d\TH:i', strtotime($tugas->deadline)) : '' }}" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <textarea name="description" rows="4" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">{{ $tugas->description }}</textarea>
      <input type="file" name="file" accept=".pdf,.ppt,.pptx,.doc,.docx">
      <select name="status" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
        <option value="open" {{ $tugas->status=='open' ? 'selected' : '' }}>Open</option>
        <option value="closed" {{ $tugas->status=='closed' ? 'selected' : '' }}>Closed</option>
      </select>
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" type="submit">Simpan Perubahan</button>
        <a class="btn" href="{{ route('tugas.index') }}" style="background:#eef6ff">Batal</a>
      </div>
    </div>
  </form>
</div>

@endsection
