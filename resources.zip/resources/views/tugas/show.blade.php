@extends('layouts.app')
@section('title','Detail Tugas')
@section('content')
<div class="card">
  <h3 style="margin-top:0">{{ $tugas->title }}</h3>
  <div style="color:var(--muted);margin-bottom:12px">Mapel: {{ $tugas->mapel }} — Kelas: {{ $tugas->kelas }} — Deadline: {{ $tugas->deadline ? (new \Carbon\Carbon($tugas->deadline))->format('d M Y H:i') : '-' }}</div>

  <div style="margin-bottom:12px">{!! nl2br(e($tugas->description)) !!}</div>
  <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
    @php $user = session('user'); @endphp
    @if($user && ($user->role ?? '') !== 'admin')
      <a href="{{ route('consultations.create', ['tugas_id' => $tugas->id]) }}" class="btn btn-outline" style="display:inline-flex;align-items:center;gap:8px">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 1a7 7 0 1 0 4.546 12.032L15 15l-1.232-2.232A7 7 0 0 0 8 1zM5 6.5a.5.5 0 0 1 .5-.5H7V5a.5.5 0 0 1 1 0v1h1.5a.5.5 0 0 1 .5.5V8a.5.5 0 0 1-.5.5H9v1a.5.5 0 0 1-1 0V8H6.5a.5.5 0 0 1-.5-.5V6.5z"/></svg>
        Konsultasi
      </a>
    @endif
  </div>

  @if($tugas->file_path)
    <div style="margin-bottom:12px">
      <a class="btn" href="{{ route('tugas.download',$tugas->id) }}" style="background:#eef6ff">Unduh Lampiran</a>
    </div>
  @endif

  @php $user = session('user'); @endphp

  @if($user && ($user->role ?? '') !== 'admin')
    <div class="card">
      <h4>Kumpulkan Tugas</h4>
      <form method="POST" action="{{ route('tugas.submit',$tugas->id) }}" enctype="multipart/form-data">
        @csrf
        <input type="file" name="file" accept=".pdf,.doc,.docx,.zip" required>
        <div style="margin-top:8px">
          <button class="btn btn-primary" type="submit">Kirim</button>
        </div>
      </form>
    </div>

    @if(isset($mySubmission) && $mySubmission)
      <div class="card" style="margin-top:12px">
        <h4>Status Pengumpulan Anda</h4>
        <div>File: <a href="{{ Storage::url($mySubmission->file_path) }}" target="_blank">Unduh</a></div>
        <div>Waktu: {{ $mySubmission->submitted_at }}</div>
        <div>Nilai: {{ $mySubmission->grade ?? '-' }}</div>
        <div>Komentar Guru: {!! nl2br(e($mySubmission->feedback ?? '-')) !!}</div>
        <div>Perlu Remidi: {{ $mySubmission->needs_remedial ? 'Ya' : 'Tidak' }}</div>
      </div>
    @endif
  @endif

  @if($user && ($user->role ?? '') === 'admin')
    <div style="margin-top:12px">
      <h4>Pengumpulan</h4>
      @if($submissions->isEmpty())
        <p class="muted">Belum ada pengumpulan.</p>
      @else
        <table style="width:100%;border-collapse:collapse;margin-top:8px">
          <thead>
            <tr style="text-align:left;color:var(--muted)"><th>Siswa</th><th>File</th><th>Dikirim</th><th>Nilai</th><th>Aksi</th></tr>
          </thead>
          <tbody>
            @foreach($submissions as $s)
              <tr style="border-top:1px solid #eef6ff">
                <td style="padding:12px 8px">{{ $s->user->name ?? $s->user->username ?? $s->user_id }}</td>
                <td><a href="{{ Storage::url($s->file_path) }}" target="_blank">Unduh</a></td>
                <td>{{ $s->submitted_at }}</td>
                <td>{{ $s->grade ?? '-' }}</td>
                <td style="text-align:right">
                  <form method="POST" action="{{ route('tugas.submissions.grade', $s->id) }}">
                    @csrf
                    <input type="number" name="grade" step="0.01" min="0" max="100" placeholder="Nilai" style="width:80px;padding:6px;border-radius:6px;border:1px solid #e6eefc" value="{{ $s->grade }}">
                    <input type="text" name="feedback" placeholder="Komentar singkat" style="padding:6px;border-radius:6px;border:1px solid #e6eefc" value="{{ $s->feedback }}">
                    <label style="margin-left:6px"><input type="checkbox" name="needs_remedial" {{ $s->needs_remedial ? 'checked' : '' }}> Remidi</label>
                    <button class="btn btn-primary" type="submit" style="margin-left:6px">Simpan</button>
                  </form>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      @endif
    </div>
  @endif

</div>
@endsection
