@extends('layouts.app')
@section('title','Daftar Tugas')
@section('page-title','Tugas')
@section('page-subtitle','Semangat belajar hari ini 🚀')
@section('content')
<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h3 style="margin:0">Daftar Tugas</h3>
    @if(session('user') && (optional(session('user'))->role ?? '') === 'admin')
      <a class="btn btn-primary" href="{{ route('tugas.create') }}">Buat Tugas</a>
    @endif
  </div>

  <div style="margin-top:12px">
    @if($tugas->isEmpty())
      <p class="muted">Belum ada tugas.</p>
    @else
      <table style="width:100%;border-collapse:collapse;margin-top:8px">
        <thead>
          <tr style="text-align:left;color:var(--muted)"><th>Judul</th><th>Mapel</th><th>Kelas</th><th>Deadline</th><th></th></tr>
        </thead>
        <tbody>
          @foreach($tugas as $item)
            <tr style="border-top:1px solid #eef6ff">
              <td style="padding:12px 8px">{{ $item->title }}</td>
              <td>{{ $item->mapel }}</td>
              <td>{{ $item->kelas }}</td>
              <td>{{ $item->deadline ? (new \Carbon\Carbon($item->deadline))->format('d M Y H:i') : '-' }}</td>
              <td style="text-align:right">
                <a class="btn" href="{{ route('tugas.show', $item->id) }}">Lihat</a>
                @php
                  $isAdmin = session('user') && ((optional(session('user'))->role ?? '')==='admin' || in_array(optional(session('user'))->username ?? '', ['admin1','admin2','admin3','admin4','admin5','admin6','admin7']));
                @endphp
                @if($isAdmin)
                  <a class="btn" href="{{ route('tugas.edit', $item->id) }}" style="margin-left:6px;background:#0ea5a4">Edit</a>
                  <a class="btn" href="{{ route('tugas.download', $item->id) }}" style="margin-left:6px;background:#7c3aed">Unduh</a>
                  <form action="{{ route('tugas.destroy', $item->id) }}" method="POST" style="display:inline;margin-left:6px">
                    @csrf @method('DELETE')
                    <button class="btn" style="background:#ef4444;color:#fff;border-radius:8px;padding:8px 10px" type="submit">Hapus</button>
                  </form>
                @else
                  <a class="btn" href="{{ route('tugas.download', $item->id) }}" style="margin-left:6px;background:#7c3aed">Unduh</a>
                @endif
                {{-- Konsultasi button available for students and teachers (students use it to consult teachers about this task) --}}
                <a class="btn btn-outline" href="{{ route('consultations.create', ['tugas_id' => $item->id]) }}" style="margin-left:6px;display:inline-flex;align-items:center;gap:6px">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M8 1a7 7 0 1 0 4.546 12.032L15 15l-1.232-2.232A7 7 0 0 0 8 1zM5 6.5a.5.5 0 0 1 .5-.5H7V5a.5.5 0 0 1 1 0v1h1.5a.5.5 0 0 1 .5.5V8a.5.5 0 0 1-.5.5H9v1a.5.5 0 0 1-1 0V8H6.5a.5.5 0 0 1-.5-.5V6.5z"/></svg>
                  Konsultasi
                </a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    @endif
  </div>

</div>
@endsection

