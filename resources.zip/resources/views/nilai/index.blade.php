@extends('layouts.app')
@section('title','Nilai')
@section('content')
<div class="card">
  <h3>Nilai Siswa</h3>
  <p class="muted">Rekap nilai akan muncul di sini. (Sederhana, belum ada filter)</p>
  <table style="width:100%;border-collapse:collapse;margin-top:12px">
    <thead><tr style="text-align:left;color:#607086"><th>Siswa</th><th>Tugas</th><th>Nilai</th></tr></thead>
    <tbody>
      <tr><td>-</td><td>-</td><td>-</td></tr>
    </tbody>
  </table>
</div>
@endsection
