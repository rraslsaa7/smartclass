{{-- resources/views/layouts/app.blade.php --}}

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'EduTask')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f4f7fb;
            color: #1e293b;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #f8fbff 0%, #eef6ff 100%);
            border-right: 1px solid rgba(37,99,235,0.06);
            padding: 28px 18px;
            display: flex;
            flex-direction: column;
            gap: 18px;
        }

        .logo {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: white;
            padding: 14px 16px;
            border-radius: 12px;
            font-size: 20px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 6px;
            box-shadow: 0 6px 18px rgba(37,99,235,0.12);
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 6px;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #0f172a;
            padding: 10px 12px;
            border-radius: 12px;
            transition: all 180ms ease-in-out;
            font-weight: 600;
            font-size: 15px;
        }

        .menu a .icon {
            width: 20px;
            height: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #2563eb;
            flex: 0 0 20px;
        }

        .menu a:hover {
            background: rgba(37,99,235,0.08);
            transform: translateX(4px);
            color: #0b1220;
        }

        .menu a.active {
            background: linear-gradient(90deg,#2563eb,#1d4ed8);
            color: white;
            box-shadow: 0 8px 24px rgba(37,99,235,0.12);
        }

        .menu a.active .icon {
            color: white;
        }

        .sidebar .profile {
            margin-top: auto;
            padding: 12px;
            border-radius: 12px;
            display: flex;
            gap: 12px;
            align-items: center;
            background: rgba(15,23,42,0.03);
        }

        .sidebar .profile img{
            width:40px;
            height:40px;
            border-radius:10px;
            object-fit:cover;
        }

        .main {
            margin-left: 280px;
            padding: 30px;
        }

        .topbar {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: white;
            padding: 22px 30px;
            border-radius: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.2);
        }

        .logout {
            background: white;
            color: #2563eb;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
        }

        .box {
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .box h3 {
            margin-bottom: 20px;
            color: #0f172a;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: #eff6ff;
        }

        table th {
            padding: 15px;
            text-align: left;
            color: #1d4ed8;
            font-size: 14px;
        }

        table td {
            padding: 15px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }

        table tr:hover {
            background: #f8fbff;
        }

        .btn {
            padding: 10px 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg,#2563eb,#1d4ed8);
            color: white;
        }

        .btn-warning {
            background: #facc15;
            color: white;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 30px;
            background: #dbeafe;
            color: #1d4ed8;
            font-size: 12px;
            font-weight: 600;
        }

        footer {
            margin-top: 40px;
            text-align: center;
            color: #64748b;
        }

        @media(max-width: 900px) {

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main {
                margin-left: 0;
            }

            table {
                display: block;
                overflow-x: auto;
            }

            .topbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>

<body>

<div class="sidebar">

    <div class="logo">EduTask</div>

    <nav class="menu">

        <a href="{{ route('dashboard') }}"
           class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">

            <span class="icon">🏠</span>
            <span>Dashboard</span>

        </a>

        <a href="{{ route('tugas.index') }}"
           class="{{ request()->routeIs('tugas.*') ? 'active' : '' }}">

            <span class="icon">📚</span>
            <span>Tugas</span>

        </a>

        <a href="{{ route('materi.index') }}"
           class="{{ request()->routeIs('materi.*') ? 'active' : '' }}">

            <span class="icon">📖</span>
            <span>Materi</span>

        </a>

        <a href="{{ route('consultations.index') }}"
           class="{{ request()->routeIs('consultations.*') ? 'active' : '' }}">

            <span class="icon">💬</span>
            <span>Konsultasi</span>

        </a>

        <a href="{{ route('nilai.index') }}"
           class="{{ request()->routeIs('nilai.*') ? 'active' : '' }}">

            <span class="icon">🎓</span>
            <span>Nilai</span>

        </a>

        <a href="{{ route('absensi.index') }}"
           class="{{ request()->routeIs('absensi.*') ? 'active' : '' }}">

            <span class="icon">📅</span>
            <span>Absensi</span>

        </a>

        <a href="{{ route('profil.index') }}"
           class="{{ request()->routeIs('profil.*') ? 'active' : '' }}">

            <span class="icon">👤</span>
            <span>Profil</span>

        </a>

    </nav>

    <div class="profile">

        <img src="{{ optional(session('user'))->avatar_url ?? '/images/default-avatar.png' }}">

        <div>
            <div style="font-weight:700">
                {{ optional(session('user'))->nama ?? optional(session('user'))->name ?? 'User' }}
            </div>

            <div style="font-size:13px;color:#64748b">
                {{ optional(session('user'))->role ?? 'Siswa' }}
            </div>
        </div>

    </div>

</div>

<div class="main">

    <div class="topbar">

        <div>
            <h2>@yield('page-title')</h2>
            <p>@yield('page-subtitle')</p>
        </div>

        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button class="logout">
                LOGOUT
            </button>
        </form>

    </div>

    @yield('content')

    <footer>
        © 2026 EduTask — Portal Sekolah Modern
    </footer>

</div>

</body>
</html>