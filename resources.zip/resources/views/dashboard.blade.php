@extends('layouts.app')

@php use Illuminate\Support\Str; @endphp

@section('title','Dashboard')
@section('page-title','Dashboard')
@section('page-subtitle','Semangat belajar hari ini 🚀')

@section('content')

<style>
    .cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .card {
        background: linear-gradient(135deg, #2563eb, #3b82f6);
        color: white;
        padding: 25px;
        border-radius: 20px;
        box-shadow: 0 8px 20px rgba(37, 99, 235, 0.15);
    }

    .card h2 { font-size: 32px; margin-bottom: 10px; }

    .content-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 20px;
    }

    @media(max-width:900px){ .content-grid{ grid-template-columns: 1fr } }
</style>

<div class="cards">
    <div class="card">
        <h2>{{ $tugasCount ?? 0 }}</h2>
        <p>Tugas Aktif</p>
    </div>

    <div class="card">
        <h2>{{ $materialsCount ?? 0 }}</h2>
        <p>Materi Tersedia</p>
    </div>

    <div class="card">
        <h2>{{ $avgScore ?? 0 }}</h2>
        <p>Rata-rata Nilai</p>
    </div>

    <div class="card">
        <h2>{{ $consultationsCount ?? 0 }}</h2>
        <p>Konsultasi Aktif</p>
    </div>
</div>

<div class="content-grid">

    <div class="box">
        <h3>Tugas Terbaru</h3>

        @if(($latestTugas ?? collect())->isEmpty())
            <p class="muted">Belum ada tugas terbaru.</p>
        @else
            @foreach($latestTugas as $t)
                <div class="task-item">
                    <div class="task-title">{{ $t->title ?? $t->judul ?? 'Tugas' }}</div>
                    <div class="task-deadline">Deadline: @if(isset($t->deadline)) @php $d=$t->deadline; @endphp @if(is_object($d) && method_exists($d,'format')) {{ $d->format('d M Y') }} @else {{ $d }} @endif @else - @endif</div>
                    <span class="badge">{{ $t->submissions_count ?? '' }}</span>
                </div>
            @endforeach
        @endif
    </div>

    <div class="box">
        <h3>Konsultasi Terbaru</h3>

        @if(($latestConsultations ?? collect())->isEmpty())
            <p class="muted">Belum ada konsultasi terbaru.</p>
        @else
            @foreach($latestConsultations as $c)
                <a href="{{ route('consultations.show', $c->id) }}" style="text-decoration:none;color:inherit">
                    <div class="consult-item">
                        <div class="task-title">{{ optional($c->student)->name ?? optional($c->student)->nama ?? optional($c->student)->username ?? 'Siswa' }}</div>
                        <div class="task-deadline">{{ Str::limit($c->subject, 50) }}</div>
                        <span class="badge">{{ ucfirst($c->status ?? 'open') }}</span>
                    </div>
                </a>
            @endforeach
        @endif
    </div>

</div>

@endsection
