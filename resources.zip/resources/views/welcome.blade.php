<!DOCTYPE html>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SMKN 11 Malang - SMK BISA</title>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{--blue-900:#073763;--blue-700:#0b66b3;--blue-500:#2b9cff;--muted:#607086}
    *{box-sizing:border-box}
    body{margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:#f4f8ff;color:#0b2540}
    header{background:linear-gradient(90deg,var(--blue-700),var(--blue-900));color:#fff;padding:18px 24px}
    .container{max-width:1100px;margin:0 auto;padding:32px}
    .branding{display:flex;align-items:center;gap:14px}
    .brand-logo{width:56px;height:56px;border-radius:10px;background:#fff;color:var(--blue-900);display:flex;align-items:center;justify-content:center;font-weight:700}
    nav.top{margin-left:auto}
    nav.top a{color:#fff;text-decoration:none;margin-left:14px;font-weight:600}
    .hero{display:flex;gap:28px;align-items:center;padding:48px 0}
    .hero .left{flex:1}
    .hero h1{font-size:2.2rem;margin:0;color:var(--blue-900)}
    .lead{margin-top:10px;color:var(--muted)}
    .cta{margin-top:18px;display:flex;gap:12px}
    .btn{padding:10px 16px;border-radius:8px;border:0;cursor:pointer;font-weight:600}
    .btn-primary{background:var(--blue-500);color:#fff}
    .btn-outline{background:transparent;border:1px solid var(--blue-700);color:var(--blue-700)}
    .card{background:#fff;border-radius:12px;padding:20px;box-shadow:0 6px 20px rgba(13,37,63,0.08)}
    .grid{display:grid;grid-template-columns:1fr 320px;gap:24px}
    footer{padding:28px 0;color:#6b7b8d;font-size:14px}
    @media(max-width:900px){.grid{grid-template-columns:1fr;}.hero{flex-direction:column;padding:24px 0}.branding{justify-content:space-between}nav.top{margin-left:0}}
  </style>
</head>
<body>
<!DOCTYPE html>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SMKN 11 Malang - SMK BISA</title>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{--blue-900:#073763;--blue-700:#0b66b3;--blue-500:#2b9cff;--muted:#607086}
    *{box-sizing:border-box}
    body{margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:#f4f8ff;color:#0b2540}
    header{background:linear-gradient(90deg,var(--blue-700),var(--blue-900));color:#fff;padding:18px 24px}
    .container{max-width:1100px;margin:0 auto;padding:32px}
    .branding{display:flex;align-items:center;gap:14px}
    .brand-logo{width:56px;height:56px;border-radius:10px;background:#fff;color:var(--blue-900);display:flex;align-items:center;justify-content:center;font-weight:700}
    nav.top{margin-left:auto}
    nav.top a{color:#fff;text-decoration:none;margin-left:14px;font-weight:600}
    .hero{display:flex;gap:28px;align-items:center;padding:48px 0}
    .hero .left{flex:1}
    .hero h1{font-size:2.2rem;margin:0;color:var(--blue-900)}
    .lead{margin-top:10px;color:var(--muted)}
    .cta{margin-top:18px;display:flex;gap:12px}
    .btn{padding:10px 16px;border-radius:8px;border:0;cursor:pointer;font-weight:600}
    .btn-primary{background:var(--blue-500);color:#fff}
    .btn-outline{background:transparent;border:1px solid var(--blue-700);color:var(--blue-700)}
    .card{background:#fff;border-radius:12px;padding:20px;box-shadow:0 6px 20px rgba(13,37,63,0.08)}
    .grid{display:grid;grid-template-columns:1fr 320px;gap:24px}
    footer{padding:28px 0;color:#6b7b8d;font-size:14px}
    @media(max-width:900px){.grid{grid-template-columns:1fr;}.hero{flex-direction:column;padding:24px 0}.branding{justify-content:space-between}nav.top{margin-left:0}}
  </style>
</head>
<body>
  <header>
    <div class="container" style="display:flex;align-items:center">
      <div class="branding">
        <img src="{{ asset('images/logo.png') }}" width="60">
        <div>
          <div style="font-weight:700">SMK Negeri 11 Malang</div>
          <div style="font-size:13px;color:rgba(255,255,255,0.9)">Mencetak generasi cerdas, berintegritas, dan siap bersaing di era global</div>
        </div>
      </div>
    </div>
  </header>

  <main class="container">
    <section class="hero">
      <div class="left">
        <h1>Selamat Datang di Portal Resmi SMK Negeri 11 Malang</h1>
        <p class="lead">Portal informasi terpusat untuk siswa dan guru: pengumuman, jadwal, materi, tugas, dan sarana komunikasi sekolah.</p>
        <div class="cta">
            <a class="btn btn-primary" href="{{ route('login') }}">Daftar Sekarang</a>
        </div>
      </div>

    </section>

    <section id="program" style="margin-top:18px">
      <div class="card">
          <h2 style="margin-top:0">Program Unggulan</h2>
        <p style="color:var(--muted)">Kurikulum terpadu, program ekstrakurikuler berkualitas, dan layanan bimbingan karier untuk mendukung prestasi akademik dan pengembangan soft-skill siswa.</p>
      </div>
    </section>

    <section id="kontak" style="margin-top:18px">
      <div class="card">
        <h2 style="margin-top:0">Kontak</h2>
        <p style="color:var(--muted); margin:0; line-height:1.6;">
      Alamat: Jl. Pelabuhan Bakahuni No. 1, Bakalankrajan, Kecamatan Sukun, Kota Malang, Jawa Timur 65148<br>
      Telp: +62 341 836330 | Fax: +62 341 837271<br>
      Email: info@smkn11malang.sch.id<br>
      Website: smkn11malang.sch.id | Facebook: SMKN11Malang
    </p>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <div>© 2026 SMK Negeri 11 Malang — Hak cipta dilindungi</div>
        <div style="color:var(--muted);font-size:13px">Dikembangkan untuk keperluan pendidikan. Sesuaikan konten sesuai kebijakan institusi.</div>
      </div>
    </div>
  </footer>
</body>
</html>

  <footer>
    <div class="container">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <div>© 2026 SMK Negeri 11 Malang — Hak cipta dilindungi</div>
        <div style="color:var(--muted);font-size:13px">Dikembangkan untuk keperluan pendidikan. Sesuaikan konten sesuai kebijakan institusi.</div>
      </div>
    </div>
  </footer>
</body>
</html>