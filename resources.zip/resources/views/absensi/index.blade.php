@extends('layouts.app')
@section('title','Absensi')
@section('content')
<div class="card">
  <h3>Absensi</h3>
  <p class="muted">Fitur absensi dasar. Tombol pembuatan/rekap dapat ditambahkan.</p>
  <div style="margin-top:12px">
    <p class="muted">Belum ada data absensi.</p>
  </div>
</div>
@endsection
