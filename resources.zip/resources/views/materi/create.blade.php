@extends('layouts.app')
@section('title','Upload Materi')
@section('content')
<div class="card">
  <h3>Upload Materi</h3>
  <form method="POST" action="{{ route('materi.store') }}" enctype="multipart/form-data">
    @csrf
    <div style="display:grid;gap:8px;margin-top:8px">
      <input type="text" name="title" placeholder="Judul materi" required style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="mapel" placeholder="Mapel" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <input type="text" name="kelas" placeholder="Kelas" style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <textarea name="description" rows="4" placeholder="Deskripsi" style="padding:10px;border-radius:8px;border:1px solid #e6eefc"></textarea>
      <input type="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip" required>
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" type="submit">Upload</button>
        <a href="{{ route('materi.index') }}" class="btn" style="background:#eef6ff">Batal</a>
      </div>
    </div>
  </form>
</div>
@endsection
