@extends('layouts.app')
@section('title','Materi')
@section('content')
<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h3 style="margin:0">Materi</h3>
    @if(session('user') && (optional(session('user'))->role ?? '') === 'admin')
      <a class="btn btn-primary" href="{{ route('materi.create') }}">Upload Materi</a>
    @endif
  </div>

  <div style="margin-top:12px">
    @if($materials->isEmpty())
      <p class="muted">Belum ada materi.</p>
    @else
      <ul>
        @foreach($materials as $m)
          <li style="margin-bottom:8px">
            <a href="{{ route('materi.show',$m->id) }}">{{ $m->title }}</a>
            <div class="muted">{{ $m->mapel }} — {{ $m->kelas }} — oleh {{ $m->creator->name ?? $m->creator->username ?? 'Guru' }}</div>
          </li>
        @endforeach
      </ul>
    @endif
  </div>
</div>
@endsection
