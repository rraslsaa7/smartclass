@extends('layouts.app')
@section('title','Detail Materi')
@section('content')
<div class="card">
  <h3 style="margin-top:0">{{ $materi->title }}</h3>
  <div class="muted">{{ $materi->mapel }} — {{ $materi->kelas }} — oleh {{ $materi->creator->name ?? $materi->creator->username ?? 'Guru' }}</div>

  <div style="margin-top:12px">{!! nl2br(e($materi->description)) !!}</div>

  @if($materi->file_path)
    <div style="margin-top:12px">
      <a class="btn" href="{{ route('materi.download',$materi->id) }}" style="background:#eef6ff">Unduh Materi</a>
      @if(session('user') && (optional(session('user'))->role ?? '') === 'admin')
        <form method="POST" action="{{ route('materi.destroy',$materi->id) }}" style="display:inline;margin-left:8px">
          @csrf
          @method('DELETE')
          <button class="btn" type="submit" style="background:#ffeef0;color:#b00020">Hapus</button>
        </form>
      @endif
    </div>
  @endif

</div>
@endsection
