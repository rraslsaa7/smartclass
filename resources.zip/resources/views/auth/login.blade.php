<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EduTask - Website Kolaborasi</title>
<style>
  :root{--blue-900:#073763;--blue-700:#0b66b3;--blue-500:#2b9cff;--muted:#607086}
  *{box-sizing:border-box}
  body{margin:0;font-family:Inter,Arial,Helvetica,sans-serif;background:linear-gradient(180deg,#eaf4ff,#f4f8ff);color:#07203a}
  header{background:linear-gradient(90deg,var(--blue-700),var(--blue-900));color:#fff;padding:20px;text-align:center}
  nav{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;background:transparent;padding:10px}
  nav a{color:#fff;text-decoration:none;padding:8px 14px;border-radius:8px;background:rgba(255,255,255,.08);font-weight:600}
  section{max-width:1100px;margin:auto;padding:24px}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}
  .card{background:#fff;border-radius:14px;padding:18px;box-shadow:0 8px 30px rgba(11,41,86,.06)}
  h2{color:var(--blue-700)}
  .btn{display:inline-block;background:var(--blue-500);color:#fff;padding:10px 14px;border-radius:10px;text-decoration:none;margin-top:8px;font-weight:700}
  .tag{display:inline-block;background:#e6f0ff;color:var(--blue-900);padding:4px 8px;border-radius:999px;font-size:12px;margin:2px}
  footer{text-align:center;padding:20px;color:#475569}
  .hero{padding:40px 20px;text-align:center}
  .hero h1{font-size:40px;margin:0;color:var(--blue-900)}
  .hero p{max-width:760px;margin:10px auto;color:#475569}
  input[type=text], input[type=password]{width:100%;padding:12px;margin:8px 0;border:1px solid #e6eefc;border-radius:10px}
  label{font-weight:600;color:#0b2540}
</style>
</head>
<body>
<header>
  <h1>EduTask</h1>
  <p>Platform Kolaborasi Siswa & Guru</p>
</header>
<nav>
<a href="#siswa">Fitur Siswa</a>
<a href="#guru">Fitur Guru</a>
<a href="#login">Login</a>
<a href="#kontak">Kontak</a>
</nav>
<section class="hero">
  <h1>Belajar Lebih Mudah</h1>
  <p>Upload tugas, akses materi, lihat nilai, jadwal, dan konsultasi tugas dalam satu platform modern.</p>
  <a class="btn" href="#login">Mulai Sekarang</a>
</section>
<section id="siswa">
<h2>Fitur Siswa</h2>
<div class="grid">
<div class="card"><h3>Register / Login</h3><p>Akses akun siswa dengan aman.</p></div>
<div class="card"><h3>Upload Tugas</h3><p>Upload file PDF, PPT, DOC. Mendukung CRUD tugas.</p></div>
<div class="card"><h3>Materi Pelajaran</h3><p>Simpan dan lihat materi kapan saja.</p></div>
<div class="card"><h3>Daftar Tugas</h3><p>Lihat semua tugas aktif dan deadline.</p></div>
<div class="card"><h3>Nilai & Remidi</h3><p>Cek nilai untuk mengetahui perlu remidi atau tidak.</p></div>
<div class="card"><h3>Konsultasi Guru</h3><p>Tanya jawab tugas dengan guru.</p></div>
<div class="card"><h3>Jadwal</h3><p>Jadwal pelajaran dan jadwal piket kelas.</p></div>
<div class="card"><h3>Filter & Riwayat</h3><p>Filter mapel, nama tugas, riwayat tugas, unduh PDF.</p></div>
</div>
</section>
<section id="guru">
<h2>Fitur Guru</h2>
<div class="grid">
<div class="card"><h3>Upload Materi</h3><p>Bagikan materi pembelajaran.</p></div>
<div class="card"><h3>Buat Tugas</h3><p>Atur deadline dan tutup pengumpulan otomatis.</p></div>
<div class="card"><h3>Lihat Tugas Siswa</h3><p>Pantau semua pengumpulan tugas.</p></div>
<div class="card"><h3>Nilai & Komentar</h3><p>Beri nilai, komentar, dan minta revisi.</p></div>
<div class="card"><h3>Filter Data</h3><p>Filter berdasarkan kelas dan mapel.</p></div>
<div class="card"><h3>Download Nilai</h3><p>Unduh rekap nilai siswa.</p></div>
<div class="card"><h3>Info Tugas</h3><p>Publikasi informasi tugas terbaru.</p></div>
<div class="card"><h3>Info Ujian</h3><p>Jadwal dan pengumuman ujian.</p></div>
</div>
</section>
<section id="login">
<h2>Login</h2>
<div class="card">
<form method="POST" action="{{ route('login.post') }}">
  @csrf
    <label>Username</label>
    <input name="username" type="text" placeholder="username" required>
    <label>Password</label>
    <input name="password" type="password" placeholder="********" required>
    <button class="btn" type="submit">Masuk</button>
  <p style="margin-top:8px;font-size:13px;color:#666">Belum punya akun? <a href="{{ route('register') }}" style="color:#2563eb;font-weight:bold;text-decoration:none">Daftar di sini</a></p>
</form>
</div>
</section>
<footer id="kontak">© 2026 EduTask - Website Kolaborasi Sekolah</footer>
</body>
</html>
