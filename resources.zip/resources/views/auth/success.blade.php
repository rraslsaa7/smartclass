<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login Berhasil</title>
  <style>
    body{margin:0;font-family:Inter,Arial,Helvetica,sans-serif;background:#fff;color:#0b2540;min-height:100vh;display:flex;align-items:center;justify-content:center}
    .card{background:#fafafa;border:1px solid #eee;padding:28px;border-radius:10px;box-shadow:0 8px 24px rgba(2,6,23,.06);text-align:center}
    .card h1{margin:0 0 8px 0;font-size:22px}
    .card p{margin:0;color:#475569}
    .btn{display:inline-block;margin-top:14px;padding:10px 14px;border-radius:8px;background:#2563eb;color:#fff;text-decoration:none}
  </style>
</head>
<body>
  <div class="card">
    <h1>Login Berhasil</h1>
    <p>Selamat datang — Anda berhasil masuk.</p>
    <p><a class="btn" href="/tugas">Lanjut ke Tugas</a></p>
  </div>
</body>
</html>
