<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - EduTask</title>
<style>
body{margin:0;font-family:Arial,sans-serif;background:linear-gradient(135deg,#1d4ed8,#0f172a);min-height:100vh}
.center{display:flex;justify-content:center;align-items:center;min-height:100vh}
.box{background:#fff;padding:32px;border-radius:18px;width:360px;box-shadow:0 20px 40px rgba(0,0,0,.25)}
input,select{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px}
.btn{width:100%;padding:12px;background:#2563eb;color:#fff;border:none;border-radius:10px;font-weight:bold;cursor:pointer}
.muted{font-size:13px;color:#666;margin-top:8px}
.link{color:#2563eb;font-weight:bold;text-decoration:none}
</style>
</head>
<body>
<div class="center">
    <div class="box">
        <h2>Register EduTask</h2>
        <p class="muted">Buat akun untuk mengakses dashboard dan fitur EduTask.</p>
        @if($errors->any())
            <div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:8px;margin-bottom:10px">
                <ul style="margin:0;padding-left:18px">
                    @foreach($errors->all() as $err)
                        <li>{{ $err }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('register.post') }}">
            @csrf
            <input type="text" name="nama" placeholder="Nama Lengkap" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="password_confirmation" placeholder="Konfirmasi Password" required>
            <input type="text" name="kelas" placeholder="Kelas (opsional)">
            <button class="btn" type="submit">Daftar</button>
        </form>

        <p class="muted">Sudah punya akun? <a href="{{ route('login') }}" class="link">Masuk di sini</a></p>
    </div>
</div>
</body>
</html>