@props(['headers' => []])
<div {{ $attributes->get('wrapAttrs') ?? '' }}>
  <div style="overflow:auto">
    <table {{ $attributes->merge(['class' => '']) }}>
      @if(count($headers))
        <thead>
          <tr>
            @foreach($headers as $h)
              <th>{{ $h }}</th>
            @endforeach
          </tr>
        </thead>
      @endif
      <tbody>
        {{ $slot }}
      </tbody>
    </table>
  </div>
</div>
