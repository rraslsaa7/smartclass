@props(['variant' => 'primary', 'type' => 'button', 'size' => 'md', 'href' => null])
@php
  $classes = 'btn';
  if($variant === 'primary') $classes .= ' btn-primary';
  elseif($variant === 'outline') $classes .= ' btn-outline';
  if($size === 'sm') $classes .= ' px-3 py-1';
  if($size === 'lg') $classes .= ' px-5 py-3';
@endphp

@if($href)
  <a href="{{ $href }}" {{ $attributes->merge(['class' => $classes]) }}>{{ $slot }}</a>
@else
  <button type="{{ $type }}" {{ $attributes->merge(['class' => $classes]) }}>{{ $slot }}</button>
@endif
