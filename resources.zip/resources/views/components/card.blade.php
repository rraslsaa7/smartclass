@props(['title' => null, 'class' => ''])
<div {{ $attributes->merge(['class' => trim('card '. $class)]) }}>
  @if($title)
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <h3 style="margin:0;font-size:1.05rem">{{ $title }}</h3>
      {{ $header ?? '' }}
    </div>
  @endif

  {{ $slot }}
</div>
