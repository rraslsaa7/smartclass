@extends('layouts.app')
@section('title','Konsultasi')
@section('content')
<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h3 style="margin:0">Konsultasi</h3>
    <a class="btn btn-primary" href="{{ route('consultations.create') }}">Buat Konsultasi</a>
  </div>

  <div style="margin-top:12px">
    @if($items->isEmpty())
      <p class="muted">Belum ada konsultasi.</p>
    @else
      <ul>
        @foreach($items as $it)
          <li style="margin-bottom:8px">
            <a href="{{ route('consultations.show',$it->id) }}">{{ $it->subject }}</a>
            <div class="muted">oleh {{ $it->student->name ?? $it->student->username }} — status: {{ $it->status }}</div>
          </li>
        @endforeach
      </ul>
    @endif
  </div>
</div>
@endsection
