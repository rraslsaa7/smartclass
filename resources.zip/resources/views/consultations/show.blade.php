@extends('layouts.app')
@section('title','Detail Konsultasi')
@section('content')
<div class="card">
  <h3 style="margin-top:0">{{ $consultation->subject }}</h3>
  <div class="muted">Status: {{ $consultation->status }} — oleh {{ $consultation->student->name ?? $consultation->student->username }}</div>

  <div style="margin-top:12px">
    @if($messages->isEmpty())
      <p class="muted">Belum ada pesan.</p>
    @else
      <div style="display:flex;flex-direction:column;gap:8px">
        @foreach($messages->reverse() as $m)
          <div class="card" style="background:#f8fbff;">
            <div style="font-weight:700">{{ $m->user->name ?? $m->user->username }} <span class="muted" style="font-weight:400">— {{ $m->created_at }}</span></div>
            <div style="margin-top:8px">{{ $m->message }}</div>
            @if($m->attachment_path)
              <div style="margin-top:8px"><a href="{{ Storage::url($m->attachment_path) }}" target="_blank">Unduh lampiran</a></div>
            @endif
          </div>
        @endforeach
      </div>
    @endif
  </div>

  @if($consultation->status === 'open')
    <div class="card" style="margin-top:12px">
      <form method="POST" action="{{ route('consultations.message',$consultation->id) }}" enctype="multipart/form-data">
        @csrf
        <textarea name="message" rows="3" placeholder="Tulis pesan..." style="padding:10px;border-radius:8px;border:1px solid #e6eefc"></textarea>
        <input type="file" name="attachment" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.zip">
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn btn-primary" type="submit">Kirim</button>
          @if((optional(session('user'))->role ?? '') === 'admin')
            <button class="btn" type="submit" name="action" value="close" style="background:#eef6ff">Tutup</button>
          @endif
        </div>
      </form>
    </div>
  @endif

</div>
@endsection
