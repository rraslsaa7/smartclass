@extends('layouts.app')
@section('title','Buat Konsultasi')
@section('content')
<div class="card">
  <h3>Buat Konsultasi</h3>
  @if(!empty($tugasId))
    <div style="margin-bottom:8px;color:var(--muted)">
      Konsultasi untuk tugas: <a href="{{ route('tugas.show', $tugasId) }}" class="small">Lihat Tugas</a>
    </div>
  @endif
  <form method="POST" action="{{ route('consultations.store') }}" enctype="multipart/form-data">
    @csrf
    <input type="hidden" name="tugas_id" value="{{ $tugasId ?? '' }}">
    <div style="display:grid;gap:8px;margin-top:8px">
      <input type="text" name="subject" placeholder="Judul/Topik" required style="padding:10px;border-radius:8px;border:1px solid #e6eefc">
      <textarea name="message" rows="4" placeholder="Tuliskan pertanyaan atau konteks" style="padding:10px;border-radius:8px;border:1px solid #e6eefc"></textarea>
      <input type="file" name="attachment" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.zip">
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" type="submit">Kirim</button>
        <a href="{{ route('consultations.index') }}" class="btn" style="background:#eef6ff">Batal</a>
      </div>
    </div>
  </form>
</div>
@endsection
