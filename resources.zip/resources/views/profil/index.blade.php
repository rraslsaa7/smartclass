@extends('layouts.app')
@section('title','Profil')
@section('content')
<div class="card">
  <h3>Profil</h3>
  <p class="muted">Informasi akun.</p>
  <form method="POST" action="{{ route('profil.update') }}" enctype="multipart/form-data">
    @csrf
    <div style="display:flex;gap:16px;align-items:flex-start">
      <div>
        @if(optional(session('user'))->avatar)
          <img src="{{ Storage::url(optional(session('user'))->avatar) }}" style="width:120px;height:120px;object-fit:cover;border-radius:8px" alt="avatar">
        @else
          <div style="width:120px;height:120px;background:#eef6ff;border-radius:8px;display:flex;align-items:center;justify-content:center">No foto</div>
        @endif
      </div>
      <div style="flex:1">
        <p>Nama:</p>
        <input type="text" name="nama" value="{{ old('nama', optional(session('user'))->nama) }}" required style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6eefc">
        <p style="margin-top:8px">Phone:</p>
        <input type="text" name="phone" value="{{ old('phone', optional(session('user'))->phone) }}" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6eefc">
        <p style="margin-top:8px">Alamat:</p>
        <textarea name="address" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6eefc">{{ old('address', optional(session('user'))->address) }}</textarea>
        <p style="margin-top:8px">Upload Foto:</p>
        <input type="file" name="avatar" accept="image/*">
        <div style="margin-top:12px">
          <button class="btn btn-primary">Simpan Profil</button>
        </div>
      </div>
    </div>
  </form>

  <form method="POST" action="{{ route('profil.clear_consultations') }}" style="margin-top:12px">
    @csrf
    <button class="btn" style="background:#ffdddd" onclick="return confirm('Yakin hapus seluruh riwayat konsultasi Anda?')">Hapus Riwayat Konsultasi</button>
  </form>

  <div style="margin-top:12px">
    <p>Username: {{ optional(session('user'))->username ?? '-' }}</p>
    <p>Role: {{ optional(session('user'))->role ?? '-' }}</p>
  </div>
</div>
@endsection
