<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use App\Http\Controllers\TugasController;
use App\Http\Controllers\ConsultationController;
use App\Http\Controllers\MateriController;
use App\Http\Controllers\NilaiController;
use App\Http\Controllers\AbsensiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/login', [AuthController::class, 'loginPost'])->name('login.post');

Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::post('/register', [AuthController::class, 'registerPost'])->name('register.post');

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

// Tugas routes (basic CRUD)
Route::get('/tugas', [TugasController::class, 'index'])->name('tugas.index');
Route::get('/tugas/create', [TugasController::class, 'create'])->name('tugas.create');
Route::post('/tugas', [TugasController::class, 'store'])->name('tugas.store');
Route::get('/tugas/{tugas}', [TugasController::class, 'show'])->name('tugas.show');
Route::get('/tugas/{tugas}/edit', [TugasController::class, 'edit'])->name('tugas.edit');
Route::put('/tugas/{tugas}', [TugasController::class, 'update'])->name('tugas.update');
Route::delete('/tugas/{tugas}', [TugasController::class, 'destroy'])->name('tugas.destroy');
Route::get('/tugas/{tugas}/download', [TugasController::class, 'download'])->name('tugas.download');
Route::post('/tugas/{tugas}/submit', [TugasController::class, 'submit'])->name('tugas.submit');
Route::post('/tugas/submissions/{submission}/grade', [TugasController::class, 'grade'])->name('tugas.submissions.grade');

// Konsultasi
Route::get('/consultations', [ConsultationController::class, 'index'])->name('consultations.index');
Route::get('/consultations/create', [ConsultationController::class, 'create'])->name('consultations.create');
Route::post('/consultations', [ConsultationController::class, 'store'])->name('consultations.store');
Route::get('/consultations/{consultation}', [ConsultationController::class, 'show'])->name('consultations.show');
Route::post('/consultations/{consultation}/message', [ConsultationController::class, 'message'])->name('consultations.message');

// Materi
Route::get('/materi', [MateriController::class, 'index'])->name('materi.index');
Route::get('/materi/create', [MateriController::class, 'create'])->name('materi.create');
Route::post('/materi', [MateriController::class, 'store'])->name('materi.store');
Route::get('/materi/{materi}', [MateriController::class, 'show'])->name('materi.show');
Route::get('/materi/{materi}/download', [MateriController::class, 'download'])->name('materi.download');
Route::delete('/materi/{materi}', [MateriController::class, 'destroy'])->name('materi.destroy');

// Nilai, Absensi, Profil (simple pages)
Route::get('/nilai', [NilaiController::class, 'index'])->name('nilai.index');
Route::get('/absensi', [AbsensiController::class, 'index'])->name('absensi.index');
Route::get('/profil', [ProfileController::class, 'index'])->name('profil.index');
Route::post('/profil', [ProfileController::class, 'update'])->name('profil.update');
Route::post('/profil/clear-consultations', [ProfileController::class, 'clearConsultations'])->name('profil.clear_consultations');